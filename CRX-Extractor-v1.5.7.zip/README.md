# crx-download
Download CRX files as zip or directly.

### Store Links

1. [Chrome Store](https://chrome.google.com/webstore/detail/crx-extractordownloader/ajkhmmldknmfjnmeedkbkkojgobmljda)
2. [Microsoft Edge Store](https://microsoftedge.microsoft.com/addons/detail/crx-extractordownloader/gfgehnhkaggeillajnpegcanbdjcbeja)
